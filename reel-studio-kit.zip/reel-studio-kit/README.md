# Reel Studio Kit

Claude Code se bina editing ke reel banao.

## Use kaise karein
1. Is folder ko terminal me kholo.
2. Setup script chalao (optional, Claude bhi khud kar dega):
   - Mac/Linux: `bash setup.sh`
   - Windows (PowerShell): `./setup.ps1`
3. `claude` chalao (Claude Code).
4. Pehli line likho: **folder ka setup karo**
5. Phir apna idea likho. Claude research, script, voiceover, animation, captions banayega.
6. Hook pasand nahi aaya? Likho: **hook punchy**

Final video: `06_output/`
