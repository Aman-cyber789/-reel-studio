#!/usr/bin/env bash
set -e
echo "== Reel Studio Kit setup =="
install_pkg() {
  if command -v brew >/dev/null 2>&1; then brew install "$1"
  elif command -v apt-get >/dev/null 2>&1; then sudo apt-get update && sudo apt-get install -y "$2"
  else echo "Manually install: $1"; fi
}
command -v node >/dev/null || install_pkg node nodejs npm
command -v python3 >/dev/null || install_pkg python3 python3
command -v pip3 >/dev/null || install_pkg python3 python3-pip
command -v ffmpeg >/dev/null || install_pkg ffmpeg ffmpeg
npm install
pip3 install -r requirements.txt || pip3 install --break-system-packages -r requirements.txt
node -v; python3 --version; ffmpeg -version | head -1
echo "Setup complete. Ab 'claude' chalao aur idea likho."
