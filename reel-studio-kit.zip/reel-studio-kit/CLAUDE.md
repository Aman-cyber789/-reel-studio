# Reel Studio Kit - Claude Code Instructions

Tum is folder me short-form vertical reels (9:16, 1080x1920, 30-60 sec) banate ho. User sirf topic/idea deta hai, baaki sab tum karte ho. Language: user jis language me likhe (Hinglish default).

## Pehli baar: "folder ka setup karo"
1. Check karo: Node.js (>=18), Python (>=3.9), FFmpeg installed hain ya nahi (`node -v`, `python3 --version`, `ffmpeg -version`).
2. Jo missing ho wo install karo (OS ke hisaab se: brew / winget / apt). Install se pehle user ko batao kya install karne wale ho.
3. `npm install` aur `pip install -r requirements.txt` chalao.
4. Folders confirm karo (01_research ... 06_output) aur end me "Setup complete" bolke puchho: "Pehli reel kis topic par?"

## Reel pipeline (user idea de to)
1. **Research** -> `01_research/<slug>.md` (key facts + sources, short)
2. **Script** -> `02_script/<slug>.md`
   - Line 1 = HOOK (pehle 3 sec me attention), phir 3-5 punchy points, end me CTA.
   - Short sentences, bolchaal ki language.
3. **AI Voiceover** -> `03_voiceover/<slug>.mp3` (edge-tts; Hindi: hi-IN-MadhurNeural / hi-IN-SwaraNeural)
4. **Animation** -> `04_animation/` (Remotion project, scene per script line, voiceover ke timing ke saath)
5. **Captions** -> `05_captions/<slug>.srt` (word-level timing) aur video me burn-in/animated captions
6. **Final render** -> `06_output/<slug>.mp4`

## Revise commands
- "hook punchy" -> sirf hook line aur punchy karo (3 options do, best wala apply karo), voiceover + captions dobara banao.
- "shorter" / "slow" / "aur energy" -> script ya voiceover adjust karke re-render.

## Rules
- Har step ke baad 1-2 line me status do.
- Copyright music/images use mat karo; `assets/` me user ki files hi use karo.
- Facts ke liye source `01_research` me likho; unverified claim reel me mat dalo.
