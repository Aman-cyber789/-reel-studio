Write-Host "== Reel Studio Kit setup =="
if (-not (Get-Command node -ErrorAction SilentlyContinue))   { winget install -e --id OpenJS.NodeJS.LTS }
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { winget install -e --id Python.Python.3.12 }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { winget install -e --id Gyan.FFmpeg }
Write-Host "Terminal restart karke dobara chalao agar kuch naya install hua."
npm install
pip install -r requirements.txt
Write-Host "Setup complete. Ab 'claude' chalao aur idea likho."
